package GoldInTotle_7_4;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class GoldInTotleClass {

	public static class mapClass extends Mapper<LongWritable, Text, Text, Text> {
		
		public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException{
			
			String line = values.toString();
			String[] data = line.split(",",-1);
			
			if (data[7].contains("Gold") || data[7].contains("gold")) {
				context.write(new Text("Gold Word : "), new Text(data[7]));
			}
			
		}
		
	}
	
	public static class reduceClass extends Reducer<Text, Text, Text, Text> {
		
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException{
			
			for (Text t : values) {
				context.write(new Text(key), new Text(t));
			}
			
		}
		
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Gold Contain Movies");
		
		job.setJarByClass(GoldInTotleClass.class);
		job.setMapperClass(mapClass.class);
		job.setReducerClass(reduceClass.class);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		Path outputpath = new Path(args[1]);
		TextInputFormat.addInputPath(job, new Path(args[0]));
		TextOutputFormat.setOutputPath(job, outputpath);
		
		outputpath.getFileSystem(conf).delete(outputpath, true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);

	}

}
