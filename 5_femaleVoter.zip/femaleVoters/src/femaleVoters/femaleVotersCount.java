package femaleVoters;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class femaleVotersCount {

	public static class map extends Mapper<LongWritable, Text, Text, IntWritable>{
		
		public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
			
			String line = values.toString();
			String[] data = line.split(",");
			if(data[2].equalsIgnoreCase("Female")){
				context.write(new Text("Female Vouters : "), new IntWritable(1));
			}
				
		}

	}
	
	public static class reduce extends Reducer<Text, IntWritable, Text, IntWritable>{
		
		public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
			
			int sum = 0;
			for (IntWritable val : values) {
				sum = sum + val.get();
			}
			
			context.write(new Text(key) ,new IntWritable(sum));
			
		}
		
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Female counter");
		
		job.setJarByClass(femaleVotersCount.class);
		job.setMapperClass(map.class);
		job.setReducerClass(reduce.class);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		Path outputpath = new Path(args[1]);
		TextInputFormat.addInputPath(job, new Path(args[0]));
		TextOutputFormat.setOutputPath(job, outputpath);
		
		outputpath.getFileSystem(conf).delete(outputpath, true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
		

	}

}
