package moreThan4;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class more_than_4_len {

	public static class mapClass extends Mapper<LongWritable, Text, Text, IntWritable> {
		
		
		public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException{
			
			String[] data = values.toString().split(" ");
			
			
			 for (String word : data) {
	                if (word.length() >= 4) {
	                    context.write(new Text("Total"), new IntWritable(1));
	                }
	            }
			
			
		}
		
	}
	
	
	public static class reduceClass extends Reducer<Text, IntWritable, Text, IntWritable> {
		
		int totalWord = 0;

		public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException{
			
			
			for (IntWritable x : values) {
				totalWord += x.get();
            }
			
			context.write(new Text("Total Words more than 4 chars: "), new IntWritable(totalWord));
			
		}

	    
		
	}
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "More thann 4 chars");
		
		job.setJarByClass(more_than_4_len.class);
		job.setMapperClass(mapClass.class);
		job.setReducerClass(reduceClass.class);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		Path outputpath = new Path(args[1]);
		TextInputFormat.addInputPath(job, new Path(args[0]));
		TextOutputFormat.setOutputPath(job, outputpath);
		
		outputpath.getFileSystem(conf).delete(outputpath, true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
		
	}

}
