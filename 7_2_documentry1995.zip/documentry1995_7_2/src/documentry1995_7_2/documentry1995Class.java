package documentry1995_7_2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class documentry1995Class {

	public static class mapClass extends Mapper<LongWritable, Text, Text, IntWritable>{
		
		public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException{
			
			String line = values.toString();
			String[] data = line.split(",",14);
			
			
			 // IMPORTANT CHECK
		    if (data.length >= 13) {

		        String genre = data[2].trim();
		        String releaseDate = data[12].trim();

		        if (releaseDate.length() >= 4) {

		            String year = releaseDate.substring(0, 4);

		            if (genre.contains("Documentary") && year.equals("1995")) {
		                context.write(new Text("Documentary-1995"),
		                              new IntWritable(1));
		            }
		        }
		    }
			
		}
		
	}
	
	public static class reduceClass extends Reducer<Text, IntWritable, Text, IntWritable>{
		
		public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException{
			
			int sum = 0;
			
			for (IntWritable i : values) {
				
				sum = sum + i.get();
				
			}
			
			context.write(key, new IntWritable(sum));
			
		}
		
	}
	
	public static void main(String[] args) throws Exception{

		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Documentry in 1995");
		
		job.setJarByClass(documentry1995Class.class);
		job.setMapperClass(mapClass.class);
		job.setReducerClass(reduceClass.class);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		Path outputpath = new Path(args[1]);
		TextInputFormat.addInputPath(job, new Path(args[0]));
		TextOutputFormat.setOutputPath(job, outputpath);
		
		outputpath.getFileSystem(conf).delete(outputpath, true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
		

	}

}
