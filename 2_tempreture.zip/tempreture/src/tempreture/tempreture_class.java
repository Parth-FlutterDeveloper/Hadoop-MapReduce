package tempreture;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class tempreture_class {

	public static class mymaper extends Mapper<LongWritable, Text, Text, IntWritable> {
		
		public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
			
			String line = values.toString();
			String[] data = line.split(",");
			
			String year = data[1];
			int temp = Integer.parseInt(data[2].toString());
			
			context.write(new Text(year), new IntWritable(temp));
			
		}
		
	}
	
	public static class myreducer extends Reducer<Text, IntWritable, Text, IntWritable>{
		
		public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		
			int min_temp = Integer.MAX_VALUE;
		
			for (IntWritable i : values) {
				if (i.get() < min_temp) {
					min_temp = i.get();
				}
			}
			
			context.write(key, new IntWritable(min_temp));
			
		}
		
	}
	
	public static void main(String[] args) throws Exception{
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Temperature Min Job");
		
		job.setJarByClass(tempreture_class.class);
		job.setMapperClass(mymaper.class);
		job.setReducerClass(myreducer.class);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		Path outputpath = new Path(args[1]);
		TextInputFormat.addInputPath(job, new Path(args[0]));
		TextOutputFormat.setOutputPath(job, outputpath);
		
		outputpath.getFileSystem(conf).delete(outputpath, true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
		
		
	}

}
